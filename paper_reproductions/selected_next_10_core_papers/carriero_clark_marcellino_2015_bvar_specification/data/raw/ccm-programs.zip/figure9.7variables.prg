********************* 7-variable model
********************* baseline specification:  Normal-Wishart, levels, all UR priors, 13 lags, fixed shrinkage, MCMC estimation
*********************
comp outfile = 'fcseries.var7.baseline.rat'

dis %dateandtime()
dis %ratsversion()

comp ndraws = 5000

*********************
********************* BASIC SETUP & PARAMETER ENTRY
*********************

comp styr = 1973
cal(m) styr:1
comp stsmpl = styr:1	;*earliest period with data
comp endpt = 2010:3   	;*last period with data

comp fcst = 1986:1   ;* starting point of forecasting
comp maxh = 12       ;* we consider forecasts 1-maxh steps ahead

comp stpt = 1974:2   ;* starting point of estimation for VAR models
comp nvar = 7    	;* number of variables in the VAR
comp baselags = 13   ;* # of lags in benchmark model

all endpt+maxh   
smpl stsmpl endpt

seed 244   ;* random number seed.  Using this same seed should produce the same results when the program is re-run.

*********************
********************* READING IN DATA
*********************

open data US.xls  
data(format=xls,org=col) / ur pcepi pcexfepi payrolls weeklyhrs claims retailsales consconf starts ip cu pmisupdeliv pmiorders poil sp500 itb10y ffr realxr
close

*********************
********************* DATA TRANSFORMATIONS and setting up data vectors
*********************
dec vec[ser] y(nvar)  ylevel(nvar) 
dec vec[str] varlabel(nvar)

** transformation indicator: 0 for levels, 1 for 1200*log level, 2 for 100*log level
comp [vec[int]] transvec = ||0,1,1,1,2,1,0||

*** form log levels and levels for conventional MPLS BVAR
comp cnt = 0
dofor i = ur pcexfepi payrolls retailsales starts ip ffr
 comp cnt = cnt + 1
 if transvec(cnt)==0
  {
   set(scratch) y(cnt) = i{0}
   set(scratch) ylevel(cnt) = i{0}
  }
 else if transvec(cnt)==1
  {
   set(scratch) y(cnt) = 1200.*log(i{0}/i{1})
   set(scratch) ylevel(cnt) = 1200.*log(i{0})
  }
 else if transvec(cnt)==2
  {
   set(scratch) y(cnt) = 100.*log(i{0}/i{1})
   set(scratch) ylevel(cnt) = 100.*log(i{0})
  }
 comp varlabel(cnt) = %l(i)
end do i

********************************
******************************** stuff for estimation of BVARs
********************************
sou(noecho) fcmoments.src     ;* procedure for forming forecast means, percentiles, PITS, etc.
sou(noecho) BVARnormalWishart.dumobs.src  ;* procedure for forming estimates of VAR with Normal-Wishart prior, and forecasts from the model

* shrinkage hyperparams for N-W case:  overall tightness, decay on lag, intercept, sum of coefs, initial obs
comp [vec] shrinkage = ||0.2,1.,1.,1.,1.|| 

comp [vec] bvarprior = %fill(nvar,1,1.0)  ;* prior means of first lag of dep variable in each equation; default prior mean is 1.0

do i = 1,nvar
 dis varlabel(i) @14 ####### transvec(i) ######.# bvarprior(i) 
end do i

********************************
******************************** stuff for storage of forecasts and results
********************************
dec rec[ser] fc_var(nvar,maxh)
smpl stpt endpt+maxh
clear fc_var

dec rec[ser] fcall(nvar,maxh)
smpl stpt endpt+maxh
clear fcall 

** series for storing log scores
dec vec[ser] LS_sys(maxh)
dec rec[ser] LS(nvar,maxh) 
clear LS LS_sys  

********************************
******************************** loop over time to form VAR forecasts
********************************

dis %datelabel(fcst) %datelabel(endpt-maxh+1)

dis %dateandtime()

do time = fcst,endpt-maxh+1

 @BVARNWdum(noprpostmean) ylevel stpt time-1 baselags baselags ndraws bvarprior shrinkage maxh Pi_post Sigma_post PiRes Sigmares forecastres marglike predlike

 ******* transform forecasts to units of interest
 do i = 1,nvar
  if transvec(i)==0
   next
  do draw = 1,ndraws
    diff forecastres(draw,i) time time+maxh
  end do draws
 end do i

  *** construction of forecast moments
  @FCMOMENTS ForecastRes y time maxh meanres pct15res pct85res pitres scoreres 
  *** storage of forecast moments into series
  do i = 1,nvar
   do h = 1,maxh
    comp fcall(i,h)(time+h-1) = meanres(i,h)
   end do h
  end do i
  *
  do j = 1,maxh
   comp LS_sys(j)(time+j-1) = scoreres(nvar+1,j) ;* score for all variables
   do i = 1,nvar
    comp LS(i,j)(time+j-1) = scoreres(i,j) ;* score for each variable
   end do i
  end do j
  
end do time

dis %dateandtime()

********************************
******************************** writing point forecasts and other density related-stuff and PIT series to RATS datafile
********************************
smpl fcst endpt

do n = 1,nvar
 do h = 1,maxh
  labels fcall(n,h)
  # 'fc'+'_'+%string(n)+'_'+%string(h)
  labels LS(n,h)
  # 'qs'+'_'+%string(n)+'_'+%string(h)
 end do h
end do n

do h = 1,maxh
   labels LS_sys(h)
   # 'qs_sys_'+%string(h)
end do h

dedit(new) &outfile
do h = 1,maxh
 do n = 1,nvar
  store fcall(n,h) LS(n,h) 
 end do n
 store ls_sys(h)
end do h
save

********************************
******************************** comp RMSEs
********************************

dec rec rmses(nvar,maxh) means(nvar,maxh) scores(nvar,maxh)

smpl fcst endpt

do i = 1,nvar
  do h = 1,maxh
   set error = (y(i){0} - fcall(i,h){0})
   stats(noprint) error
   comp means(i,h) = %mean
   set errorsq = (y(i){0} - fcall(i,h){0})**2.
   stats(noprint) errorsq
   comp rmses(i,h) = %mean^.5
  end do h
end do i

********************************
******************************** display results for mean errors, and RMSES
********************************

do j = 1,nvar
  comp [vec] tempvec = %xrow(means,j)
  dis varlabel(j) @12 ###.### tempvec
end do j

do j = 1,nvar
  comp [vec] tempvec = %xrow(rmses,j)
  dis varlabel(j) @12 ###.### tempvec
end do j

dis %dateandtime()

********************************
******************************** average log scores:  vector of variables
********************************
smpl fcst endpt
dec vec scoreresults(maxh)

****
do hh = 1,maxh
 stats(noprint) LS_sys(hh)
 comp scoreresults(hh) = %mean
end do hh
****
dis @14 ###.### scoreresults

********************************
******************************** average log scores:  variable by variable
********************************
smpl fcst endpt
dec vec scoreresults(maxh)

****
do ii = 1,nvar
 do hh = 1,maxh
  stats(noprint) LS(ii,hh) 
  comp scoreresults(hh) = %mean
 end do hh
 dis varlabel(ii) @12 ###.### scoreresults
end do ii
